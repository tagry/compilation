#include <stdio.h>
#include <stdlib.h>

int main()
{
	i = 5;// i n'est pas déclaré
	return 0;
}
