#include <stdio.h>
#include <stdlib.h>

int main()
{
  int A[100];
  int B[50];
  int C = A * B;

  return EXIT_SUCCESS;

}
