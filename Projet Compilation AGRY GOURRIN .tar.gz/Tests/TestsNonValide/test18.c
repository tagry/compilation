#include <stdio.h>
#include <stdlib.h>

int main()

  int bonjour = 1;
  return bonjour;
}
