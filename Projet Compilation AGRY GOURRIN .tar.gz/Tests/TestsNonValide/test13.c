#include <stdio.h>
#include <stdlib.h>

int bonjour()
{
  int A[100];
  int B[50];

  return EXIT_SUCCESS;

}
