#include <stdio.h>
#include <stdlib.h>

int main()
{
	int g(int x, int b)//Fonction déclaré dans un bloc de fonction
	{
		return x;
	}
	return 0;
}
