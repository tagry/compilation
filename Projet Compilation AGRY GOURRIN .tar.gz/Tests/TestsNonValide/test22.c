#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i = 0
  return i;
}
