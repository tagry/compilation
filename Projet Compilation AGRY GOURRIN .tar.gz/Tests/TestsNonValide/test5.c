#include <stdio.h>
#include <stdlib.h>

int main()
{
	int i = 5;
	int i = 6;//déclaration multiple
	
	return 0;
}
