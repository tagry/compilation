#include <stdio.h>
#include <stdlib.h>

int main()
{
	int A[100];
	int C[200];

	C = A; // C est plus grand que A donc le compilateur indique qu'il n'est pas possible de compiler
	
	return 0;
}
