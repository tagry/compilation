#include <stdio.h>
#include <stdlib.h>

int main()
{
	int a = 0;// Test des affectations
	int b = 8;
	int c = b;//test des affectations de variables dans variable

	a = 4 + 2;
	a = 4 - 2;
	a = 4 * 2;
	a = 4 / 2;

	a = b + c;//Operation sur variables
	a = b - c;
	a = b * c;
	a = b / c;

	return 0;
}
