#include <stdio.h>
#include <stdlib.h>

int f()
{
  int A[3] = {1, 2, 3};
  return A;
}

int main()
{
  f();
  return 0;
}
