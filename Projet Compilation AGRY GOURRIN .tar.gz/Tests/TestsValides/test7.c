#include <stdio.h>
#include <stdlib.h>

extern void printint(int x);

int main()
{
	int x = 0;
	printint(x);
	return 0;
}
