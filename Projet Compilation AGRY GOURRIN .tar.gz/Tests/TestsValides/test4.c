#include <stdio.h>
#include <stdlib.h>

int main()
{
	int i = 0;
	int x = 0;

	for(i = 0; i < 5; i+1)
	{
		x = x+1;
	}
	return 0;// x == 4
}
