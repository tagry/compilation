#include <stdio.h>
#include <stdlib.h>

int main()
{
	int A[100];
	int B[200];

	A = B ; // ok car B est plus grand que A
	
	
	return 0;
}
