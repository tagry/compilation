#include <stdio.h>
#include <stdlib.h>


int main()
{
  return (1==2);
}
