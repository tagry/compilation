#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x = 0;
	while(x<6)
	{
		x = x+1;
	}//x = 6

	return 0;
}
